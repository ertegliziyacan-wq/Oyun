package com.can.sinirlikuslar

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.min
import kotlin.random.Random

class GameView(context: Context, private val voice: (String) -> Unit) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private data class Pipe(var x: Float, val top: Float, val gap: Float, var passed: Boolean = false)
    private var pipes = mutableListOf<Pipe>()
    private var birdY = 0f
    private var birdV = 0f
    private var score = 0
    private var best = 0
    private var started = false
    private var gameOver = false
    private var muted = false
    private var lastTime = 0L
    private var spawn = 0f
    private var scale = 1f
    private var groundY = 0f
    private var bubble = ""
    private var bubbleUntil = 0L
    private val gravity = 1450f
    private val flapPower = -470f
    private val pipeSpeed = 190f
    private val birdX get() = width * 0.26f
    private val birdR get() = 19f * scale
    private val gap get() = 178f * scale
    private val pipeW get() = 62f * scale
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
    }

    init {
        isFocusable = true
        reset()
    }

    fun stopGame() { started = false }

    private fun reset() {
        birdY = height.takeIf { it > 0 }?.let { it * 0.42f } ?: 300f
        birdV = 0f
        score = 0
        pipes.clear()
        spawn = 0f
        started = false
        gameOver = false
        bubble = ""
        lastTime = 0L
        invalidate()
    }

    private fun say(message: String) {
        bubble = message
        bubbleUntil = System.currentTimeMillis() + 1100
        if (!muted) voice(message)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        scale = min(w / 420f, h / 620f).coerceAtLeast(0.65f)
        groundY = h - 62f * scale
        if (!started) birdY = h * 0.42f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        drawBackground(canvas, w, h)
        drawPipes(canvas)
        drawBird(canvas)
        drawHud(canvas, w)
        if (bubble.isNotEmpty() && System.currentTimeMillis() < bubbleUntil) drawBubble(canvas, w)
        if (!started) drawOverlay(canvas, w, h)
        if (started && !gameOver) {
            val now = System.nanoTime()
            if (lastTime == 0L) lastTime = now
            val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0f, 0.035f)
            lastTime = now
            update(dt)
            postInvalidateDelayed(16)
        }
    }

    private fun update(dt: Float) {
        birdV += gravity * scale * dt
        birdY += birdV * dt
        spawn += dt
        if (spawn > 1.55f) {
            val top = (height * 0.18f + Random.nextFloat() * height * 0.32f).coerceIn(95f * scale, groundY - gap - 90f * scale)
            pipes.add(Pipe(width + pipeW, top, gap))
            spawn = 0f
        }
        val iterator = pipes.iterator()
        while (iterator.hasNext()) {
            val pipe = iterator.next()
            pipe.x -= pipeSpeed * scale * dt
            if (pipe.x + pipeW < -10) iterator.remove()
            if (!pipe.passed && pipe.x + pipeW < birdX) {
                pipe.passed = true
                score++
            }
            val birdLeft = birdX - birdR * 0.78f
            val birdRight = birdX + birdR * 0.78f
            val overlapsX = birdRight > pipe.x && birdLeft < pipe.x + pipeW
            val hitsGap = birdY - birdR < pipe.top || birdY + birdR > pipe.top + pipe.gap
            if (overlapsX && hitsGap) { endGame(); return }
        }
        if (birdY + birdR >= groundY || birdY - birdR <= 0) endGame()
    }

    private fun endGame() {
        if (gameOver) return
        gameOver = true
        started = false
        if (score > best) best = score
        say("Lâ havle!")
        invalidate()
    }

    private fun drawBackground(c: Canvas, w: Float, h: Float) {
        c.drawColor(Color.rgb(104, 207, 245))
        p.color = Color.WHITE
        c.drawCircle(w * .18f, h * .16f, 24f * scale, p)
        c.drawCircle(w * .23f, h * .145f, 18f * scale, p)
        c.drawCircle(w * .28f, h * .16f, 22f * scale, p)
        c.drawCircle(w * .73f, h * .23f, 25f * scale, p)
        c.drawCircle(w * .78f, h * .21f, 18f * scale, p)
        p.color = Color.rgb(119, 202, 111)
        val hill = android.graphics.Path().apply {
            moveTo(0f, groundY)
            quadTo(w * .25f, groundY - 115f * scale, w * .5f, groundY)
            quadTo(w * .75f, groundY - 120f * scale, w, groundY)
            lineTo(w, h); lineTo(0f, h); close()
        }
        c.drawPath(hill, p)
        p.color = Color.rgb(181, 229, 120)
        c.drawRect(0f, groundY, w, h, p)
        p.color = Color.rgb(115, 176, 69)
        c.drawRect(0f, groundY, w, groundY + 9f * scale, p)
    }

    private fun drawPipes(c: Canvas) {
        pipes.forEach { pipe ->
            p.color = Color.rgb(32, 153, 68)
            p.style = Paint.Style.FILL
            c.drawRect(pipe.x, 0f, pipe.x + pipeW, pipe.top, p)
            c.drawRect(pipe.x, pipe.top + pipe.gap, pipe.x + pipeW, groundY, p)
            p.color = Color.rgb(72, 204, 105)
            c.drawRect(pipe.x - 5f * scale, pipe.top - 19f * scale, pipe.x + pipeW + 5f * scale, pipe.top, p)
            c.drawRect(pipe.x - 5f * scale, pipe.top + pipe.gap, pipe.x + pipeW + 5f * scale, pipe.top + pipe.gap + 19f * scale, p)
            p.color = Color.rgb(15, 100, 43)
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f * scale
            c.drawRect(pipe.x, 0f, pipe.x + pipeW, pipe.top, p)
            c.drawRect(pipe.x, pipe.top + pipe.gap, pipe.x + pipeW, groundY, p)
            p.style = Paint.Style.FILL
        }
    }

    private fun drawBird(c: Canvas) {
        c.save()
        c.rotate((birdV / 900f).coerceIn(-0.45f, 0.65f) * 57f, birdX, birdY)
        p.color = Color.rgb(201, 65, 32)
        val tail = android.graphics.Path().apply {
            moveTo(birdX - 12f * scale, birdY + 3f * scale)
            lineTo(birdX - 32f * scale, birdY - 8f * scale)
            lineTo(birdX - 27f * scale, birdY + 13f * scale); close()
        }
        c.drawPath(tail, p)
        p.color = Color.rgb(235, 76, 37)
        c.drawCircle(birdX, birdY, birdR, p)
        p.color = Color.rgb(255, 205, 133)
        c.drawOval(RectF(birdX - 5f * scale, birdY + 2f * scale, birdX + 13f * scale, birdY + 15f * scale), p)
        p.color = Color.WHITE
        c.drawCircle(birdX + 8f * scale, birdY - 6f * scale, 5.5f * scale, p)
        p.color = Color.BLACK
        c.drawCircle(birdX + 10f * scale, birdY - 6f * scale, 2.2f * scale, p)
        p.color = Color.rgb(255, 181, 46)
        val beak = android.graphics.Path().apply {
            moveTo(birdX + 14f * scale, birdY + 1f * scale)
            lineTo(birdX + 29f * scale, birdY + 6f * scale)
            lineTo(birdX + 14f * scale, birdY + 11f * scale); close()
        }
        c.drawPath(beak, p)
        p.color = Color.rgb(50, 30, 25); p.strokeWidth = 4f * scale
        c.drawLine(birdX + 1f * scale, birdY - 13f * scale, birdX + 15f * scale, birdY - 16f * scale, p)
        c.restore()
    }

    private fun drawHud(c: Canvas, w: Float) {
        textPaint.textSize = 38f * scale
        c.drawText(score.toString(), w / 2, 55f * scale, textPaint)
        textPaint.textSize = 15f * scale
        textPaint.textAlign = Paint.Align.LEFT
        c.drawText("REKOR: $best", 16f * scale, 30f * scale, textPaint)
        textPaint.textAlign = Paint.Align.CENTER
    }

    private fun drawBubble(c: Canvas, w: Float) {
        p.color = Color.WHITE
        val rect = RectF(w / 2 - 112f * scale, 67f * scale, w / 2 + 112f * scale, 108f * scale)
        c.drawRoundRect(rect, 18f * scale, 18f * scale, p)
        textPaint.color = Color.rgb(35, 43, 53)
        textPaint.textSize = 17f * scale
        c.drawText(bubble, w / 2, 94f * scale, textPaint)
        textPaint.color = Color.WHITE
    }

    private fun drawOverlay(c: Canvas, w: Float, h: Float) {
        p.color = 0x66142B40
        c.drawRect(0f, 0f, w, h, p)
        textPaint.color = Color.WHITE
        textPaint.textSize = 29f * scale
        c.drawText(if (gameOver) "LÂ HAVLE! 😵" else "SİNİRLİ KUŞLAR", w / 2, h * .39f, textPaint)
        textPaint.textSize = 17f * scale
        c.drawText(if (gameOver) "Skor: $score     Rekor: $best" else "Dokun ve uç!", w / 2, h * .45f, textPaint)
        textPaint.textSize = 14f * scale
        c.drawText(if (gameOver) "Tekrar oynamak için dokun" else "Her dokunuşta selam, çarpınca lâ havle!", w / 2, h * .50f, textPaint)
        p.color = Color.rgb(245, 166, 35)
        c.drawRoundRect(RectF(w * .25f, h * .56f, w * .75f, h * .64f), 28f * scale, 28f * scale, p)
        textPaint.color = Color.rgb(56, 34, 11)
        textPaint.textSize = 19f * scale
        c.drawText(if (gameOver) "YENİDEN OYNA" else "BAŞLA", w / 2, h * .615f, textPaint)
        textPaint.color = Color.WHITE
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            if (!started) {
                if (gameOver) reset()
                started = true
                gameOver = false
                birdV = flapPower * scale
                lastTime = System.nanoTime()
                say("Selamün aleyküm!")
                invalidate()
            } else {
                birdV = flapPower * scale
                say("Selamün aleyküm!")
                invalidate()
            }
            return true
        }
        return true
    }
}
