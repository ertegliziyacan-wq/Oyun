package com.can.sinirlikuslar

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tts = TextToSpeech(this, this)
        gameView = GameView(this) { phrase -> speak(phrase) }
        setContentView(gameView)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("tr", "TR"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setSpeechRate(0.95f)
        }
    }

    private fun speak(phrase: String) {
        if (ttsReady) {
            tts?.stop()
            tts?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "sinirli-kuslar-$phrase")
        }
    }

    override fun onDestroy() {
        gameView.stopGame()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
