# Sinirli Kuşlar — Android APK projesi

- Ekrana her dokunuşta: “Selamün aleyküm!”
- Boruya, zemine veya üst sınıra çarpınca: “Lâ havle!”

## Ücretsiz APK oluşturma (telefon üzerinden GitHub Actions)

1. GitHub'da yeni ve **Public** bir repository oluştur (ör. `sinirli-kuslar`).
2. Bu ZIP'i telefonda çıkar. İçindeki tüm dosya ve klasörleri (özellikle `.github` klasörü dahil) repository'nin ana dizinine yükle. `.github` gizli klasörünü yükleyemiyorsan GitHub web arayüzünde `Add file > Create new file` ile `.github/workflows/android.yml` oluşturup ZIP'teki aynı adlı dosyanın içeriğini yapıştır.
3. Repository'de **Actions** sekmesini aç. İlk kullanımda “I understand my workflows, go ahead and enable them” görünürse onayla.
4. Soldan **Build Sinirli Kuslar APK** iş akışını seç, **Run workflow** ve tekrar **Run workflow** düğmesine bas.
5. İşlem tamamlanınca yeşil başarılı çalıştırmaya gir. Sayfanın altındaki **Artifacts** bölümünden `Sinirli-Kuslar-debug-apk` dosyasını indir.
6. İnen ZIP'i telefonda çıkar; `app-debug.apk` dosyasını açıp kur.

## Proje notları
- Android Gradle Plugin 8.9.2, Kotlin 2.1.20, Gradle 8.11.1 ve Java 17 kullanır.
- Derleme GitHub Actions üzerinde ücretsiz kotayı kullanır; GitHub hesabı ve repository gerekir. Ücretsiz kullanım koşulları/limitleri GitHub hesabına göre değişebilir.
- APK imzası debug anahtarıyla yapılır; kişisel test/kurulum içindir.
- Türkçe ses için telefonda Türkçe metin okuma (TTS) dili bulunmalıdır.
